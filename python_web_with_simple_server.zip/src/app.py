import sys
import os
import json
import cgi

from wsgiref import simple_server, util
from wsgiref.simple_server import make_server

def application(environ, res):
    
    #print(environ['PATH_INFO']) # http://localhost:8000/
    #print(environ)
    
    # os.path.join('src/templates/index.html')
    index_file = 'src/static/index.html' 
    
    # os.path.join('src/templates/about.html')
    about_file = 'src/static/about.html' 
        
    if environ['PATH_INFO'] == '/':
        headers = [('Content-type', 'text/html')]
        res('200 OK', headers)
        return util.FileWrapper(open(index_file, "rb"))
    elif environ['PATH_INFO'] == '/about':
        headers = [('Content-type', 'text/html')]
        res('200 OK', headers)
        return util.FileWrapper(open(about_file, "rb"))
    elif environ['PATH_INFO'] == '/test1':
        headers = [('Content-type', 'text/plain; charset=utf-8')]
        res('200 OK', headers)
        return [b'Hello World']
    elif environ['PATH_INFO'] == '/test2':
        headers = [('Content-type', 'text/html')]
        res('200 OK', headers)
        message = '<html><body><h1>YEP</h1><body></html>'
        res = '\n'.join([message])
        return [res.encode()] 
    elif environ['PATH_INFO'] == '/testjson':
        # https://stackoverflow.com/questions/8445974/how-to-read-json-object-using-ajax-from-a-python-wsgi-application
        # https://python.hotexamples.com/examples/wsgiref.util/-/request_uri/python-request_uri-function-examples.html
        # json.loads converts a string to a JSON object
        # By contrast, json.dumps converts a json object to a string
        json_str = '[{"name":"John Johnson", "age":33}]'
        status = '200 OK'
        headers = [('Content-Type', 'application/json')]
        res(status, headers)
        res = ''.join([json_str])
        return [res.encode()]
    #elif environ['PATH_INFO'] == '/passenger_wsgi.py': # <form name="searchform" action="/passenger_wsgi.py" method="post"> 
    elif environ['PATH_INFO'] == '/testpost':
        form = cgi.FieldStorage(environ["wsgi.input"], environ=environ)
        searchterm = form.getvalue("searchbox")  
        if searchterm is not None:
            headers = [('Content-type', 'text/html')]
            res('200 OK', headers)
            message = '<html><body><h1> You searched for: ' + searchterm + '</h1><body></html>'
            res = '\n'.join([message])
            return [res.encode()]
        else:
            headers = [('Content-type', 'text/html')]
            res('200 OK', headers)
            message = '<html><body><h1> ' + str(type(searchterm)) + ' </h1><body></html>'
            res = '\n'.join([message])
            return [res.encode()]    
    else:
        start_response('404 Not Found', [('Content-Type', 'text/plain')])
        return [b'not found']

#httpd = make_server('localhost',8000, application)
#httpd.serve_forever()
